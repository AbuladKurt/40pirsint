<?php 

    include 'config.php';
    session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add user</title>
    <link rel="stylesheet" href="try.css">
</head>
<body>
    <div class="container">
    <div class="navlinks">
       
        <ul>
        <li><a href="view.php">
                    <?php

                        $email = $_SESSION['user_name'];

                        if ($email == true) {



                        } else {

                            header('location:logingin.php');

                        }

                        echo $_SESSION['firstname'];
                     
                    ?>
                </a></li>
            <li><a class="btn" href="view.php">View Users</a></li>
            <li><a class="btn" href="user.php">Add User</a></li>
            <li><a class="btn" href="#">Contacts</a></li>
            <li><a class="btn" href="#">Mission and Vision</a></li>
            <li><a href="logout.php" class="btn">Logout</a></li>
        </ul>
    
    </div>
    <div class="form-container">
    <form action="" method="post">
    <label for="fname">First name</label>
    <input type="text" id="fname" name="fname"  autocomplete="off" required>
   
    <label for="lname">Last name</label>
    <input type="text" id="lname" name="lname" autocomplete="off" required>

    <label for="mname">Middle name</label>
    <input type="text" id="mname" name="mname" autocomplete="off" required>
   
     <label for="email">Email</label>
    <input type="email" id="email" name="email" autocomplete="off" required>
    
     <label for="usern">Username</label>
    <input type="text" id="usern" name="username" autocomplete="off" required>
   
     <label for="pass">Password</label>
    <input  type="password" id="pass" name="password" autocomplete="off" required>
        
        <label for="contact">Contact</label>
    <input  type="text" id="contact" name="contact" autocomplete="off" required>
   <div class="gender">
    <input type="radio" name="gender" value="Male">Male
    <input type="radio" name="gender" value="Female">Female 
   </div>
  
    <label>Role : </label>
    <select name="role" autocomplete="off" required>
    <option value="" class=".dropdown-content">Select</option>
    <option value="admin">Admin</option>
    <option value="faculty">Faculty</option>
    <option value="student">Student</option>
    </select>
    <br>
    <input type="submit" class="add" name="submit" value="submit">
    </form>
    </div>
    </div>
    </div>


   
</body>
</html>


<?php 

    if(isset($_POST['submit'])) {
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $mname = $_POST['mname'];
        $email = $_POST['email'];
        $username = $_POST['username'];
        $password = md5($_POST['password']);
        $contact = $_POST['contact'];
        $gender = $_POST['gender'];
        $role = $_POST['role'];


        $qry = "INSERT INTO user values (null, '$fname', '$lname', '$mname', '$email', '$username', '$password', '$contact', '$gender', '$role')";

        if(mysqli_query($conn, $qry)) {

            echo "User Registered Successfully";
            header('location:view.php');

        } else {

            mysqli_error($conn);

        }


    }

?>