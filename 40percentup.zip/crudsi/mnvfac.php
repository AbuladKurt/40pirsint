<?php 

    include 'config.php';
    session_start();


?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial scale=1.0">
        <title>Homepage</title>
        <link rel="stylesheet" href="faculty.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,200;0,300;0,400;0,700;1,200;1,400&display=swap" rel="stylesheet">
    </head>
    <style>
          fieldset {
        background-color: transparent;
        margin: 40px 70px;
        padding: 1em 2em;
         border: solid 2px #fff;
         min-width: 100px;
         border-radius: 18px;
         }
         p{
             color: #fff;
             font-size: 16px;
             font-weight: 400;
         }
         h1{
             color: #fff;
             font-size: 40px;
             font-weight: 600;
         }

         .nameleft a {

            text-decoration: none;
            color: white;

         }
    </style>
    <body>
    
        <section class="header">
            <nav>
                <div class="nameleft">
                <a href="faculty.php">
                    <?php

                        $email = $_SESSION['user_name'];

                        if ($email == true) {



                        } else {

                            header('location:logingin.php');

                        }

                        echo "Welcome Faculty," . " " .  $_SESSION['firstname'];
                     
                    ?>
                </a>
                </div>
                <div class="nav-links">
                    <ul>
                        <li><a href="faculty.php">Home</a></li>
                        <li><a href="">My Courses</a></li>
                        <li><a href="mnvfac.php">Mission and Vision</a></li>
                        <li><a href="abtfac.php">About</a></li>
                        <li><a href="logout.php">Logout</a></li>
                    </ul>
                </div>
            </nav>
            <fieldset>
                <div class="VMission">
                <h1>Vision</h1>
               <p> Our vision is to foster balanced, certain and dependable people who try to accomplish their maximum capacity. We will do this by providing an LMS<br>for an inviting, cheerful, safe, and steady learning climate in which everybody is equivalent and all accomplishments are commended.</p>
                <h1>Mission</h1>
                    <p>To teach all students the most significant levels of scholastic accomplishment, to empower them to reach and extend their true<br>capacity, and to set them up to become useful, dependable, moral, imaginative and merciful citizenry.</p>
                 <h1>Values</h1>
                     <p>Commitment</p>
                     <p>Integrity</p>
                     <p>Passion</p>
                     <p>Respect</p>
                     <p>Professionalism</p>
                     <p>Teamwork</p>
        
                </div>
                </fieldset>   
        </section>

    </body>
</html>