<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mission</title>
</head>
<body>
<nav>

            <fieldset>
                <div class="VMission">
                <h1>Vision</h1>
               <p> Our vision is to foster balanced, certain and dependable people who try to accomplish their maximum capacity. We will do this by providing an E-Lirbrary<br>for an inviting, cheerful, safe, and steady learning climate in which everybody is equivalent and all accomplishments are commended.</p>
                <h1>Mission</h1>
                    <p>To teach all students the most significant levels of scholastic accomplishment, to empower them to reach and extend their true<br>capacity, and to set them up to become useful, dependable, moral, imaginative and merciful citizenry.</p>
                 <h1>Values</h1>
                     <p>Commitment</p>
                     <p>Integrity</p>
                     <p>Passion</p>
                     <p>Respect</p>
                     <p>Professionalism</p>
                     <p>Teamwork</p>
        
                </div>
                </fieldset>

</body>
</html>