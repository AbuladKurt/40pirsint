<?php 

    include 'config.php';

    $id = $_GET['id'];

    $qry = "DELETE FROM user WHERE user_id = $id";
    if(mysqli_query($conn, $qry)) {

        header('location:view.php');

    } else {

        echo mysqli_error($conn);

    }

?>